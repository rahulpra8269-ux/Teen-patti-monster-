
import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const TeenPattiMonster());

class TeenPattiMonster extends StatelessWidget {
  const TeenPattiMonster({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Teen Patti Monster',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF090B12),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFB300),
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('👹 TEEN PATTI MONSTER',
            style: TextStyle(fontWeight: FontWeight.w900)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Row(
                children: [
                  CircleAvatar(radius: 32, child: Text('👹', style: TextStyle(fontSize: 30))),
                  SizedBox(width: 14),
                  Expanded(child: Text(
                    'MONSTER PLAYER\nVirtual Coins: 10,000',
                    style: TextStyle(fontWeight: FontWeight.bold, height: 1.5),
                  )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          GameTile(
            icon: '🐯',
            title: 'Dragon Tiger',
            subtitle: '5-second demo round',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DragonTigerPage())),
          ),
          const SizedBox(height: 12),
          GameTile(
            icon: '🃏',
            title: 'Teen Patti',
            subtitle: 'Free-to-play table demo',
            onTap: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Teen Patti demo coming next.'))),
          ),
          const SizedBox(height: 12),
          GameTile(
            icon: '🏆',
            title: 'Leaderboard',
            subtitle: 'Top virtual-coin players',
            onTap: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Leaderboard demo coming next.'))),
          ),
          const SizedBox(height: 25),
          const Text(
            'Demo only • No real-money wagering • No deposits or withdrawals',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class GameTile extends StatelessWidget {
  final String icon, title, subtitle;
  final VoidCallback onTap;
  const GameTile({super.key, required this.icon, required this.title,
      required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(children: [
            Text(icon, style: const TextStyle(fontSize: 38)),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white60)),
              ],
            )),
            const Icon(Icons.arrow_forward_ios, size: 18),
          ]),
        ),
      ),
    );
  }
}

class DragonTigerPage extends StatefulWidget {
  const DragonTigerPage({super.key});
  @override
  State<DragonTigerPage> createState() => _DragonTigerPageState();
}

class _DragonTigerPageState extends State<DragonTigerPage> {
  Timer? timer;
  int seconds = 5;
  bool bettingOpen = true;
  String result = 'Choose a side';
  int dragon = 0, tiger = 0;
  final random = Random();

  @override
  void initState() {
    super.initState();
    startRound();
  }

  void startRound() {
    timer?.cancel();
    setState(() {
      seconds = 5;
      bettingOpen = true;
      result = 'Choose a side';
      dragon = 0;
      tiger = 0;
    });
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (seconds <= 1) {
        t.cancel();
        setState(() {
          seconds = 0;
          bettingOpen = false;
          dragon = random.nextInt(13) + 1;
          tiger = random.nextInt(13) + 1;
          result = dragon == tiger
              ? 'TIE'
              : (dragon > tiger ? 'DRAGON WINS' : 'TIGER WINS');
        });
      } else {
        setState(() => seconds--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Widget side(String name, String emoji) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(children: [
            Text(emoji, style: const TextStyle(fontSize: 45)),
            Text(name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              name == 'DRAGON' ? (dragon == 0 ? '🂠' : '$dragon') :
              (tiger == 0 ? '🂠' : '$tiger'),
              style: const TextStyle(fontSize: 35),
            ),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: bettingOpen
                  ? () => setState(() => result = 'Demo selection: $name')
                  : null,
              child: Text('SELECT $name'),
            )
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('🐯 Dragon Tiger')),
      body: Column(children: [
        const SizedBox(height: 20),
        const Text('BETTING TIMER',
            style: TextStyle(color: Colors.white60, letterSpacing: 2)),
        Text('${seconds}s',
            style: const TextStyle(fontSize: 55, fontWeight: FontWeight.w900)),
        Text(bettingOpen ? 'Demo selection open' : 'Round finished'),
        const SizedBox(height: 15),
        Row(children: [side('DRAGON', '🐉'), side('TIGER', '🐯')]),
        const SizedBox(height: 15),
        Text(result,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: bettingOpen ? null : startRound,
          icon: const Icon(Icons.refresh),
          label: const Text('NEXT ROUND'),
        ),
        const Spacer(),
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text(
            'Free-to-play demonstration. No real-money bets, deposits, withdrawals, or cash prizes.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white54, fontSize: 12),
          ),
        ),
      ]),
    );
  }
}
